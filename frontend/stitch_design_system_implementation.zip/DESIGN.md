---
name: ShareRide Design System
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363941'
  surface-container-lowest: '#0b0e15'
  surface-container-low: '#191b23'
  surface-container: '#1d2027'
  surface-container-high: '#272a31'
  surface-container-highest: '#32353c'
  on-surface: '#e1e2ec'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#e1e2ec'
  inverse-on-surface: '#2e3038'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb786'
  on-tertiary: '#502400'
  tertiary-container: '#df7412'
  on-tertiary-container: '#461f00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb786'
  on-tertiary-fixed: '#311400'
  on-tertiary-fixed-variant: '#723600'
  background: '#10131a'
  on-background: '#e1e2ec'
  surface-variant: '#32353c'
  surface-main: '#0F172A'
  surface-card: '#1E293B'
  surface-glass: rgba(30, 41, 59, 0.7)
  text-primary: '#F8FAFC'
  text-secondary: '#94A3B8'
  accent-waypoint: '#F59E0B'
  map-route: '#6366F1'
typography:
  h1:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
  h2:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  h3:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  sidebar-width: 400px
  mobile-sidebar-height: 40vh
  gutter: 1.5rem
  stack-gap: 1rem
  section-padding: 2rem
---

# ShareRide Web Application Design

## Overview
ShareRide is a ride-sharing platform designed to facilitate cost-splitting for booked rides (Uber, Ola, etc.). It connects "hosts" (users who have booked or intend to book a ride) with "passengers" (users traveling along a similar route) by matching pickup and destination locations within user-defined radii.

## Core Features
- **Post a Ride**: Users can list a ride by specifying pickup/destination (via Mapbox search or map pin), date/time, price, and available seats.
- **Find a Ride**: Users can search for rides by defining their own pickup/destination and acceptable "walking" radii for both ends.
- **Proximity Matching**: Backend uses PostGIS (`ST_DWithin`) to find rides where both the pickup and drop-off points are within the requested distance from the user's points.
- **Visual Mapping**: Interactive Mapbox integration to visualize search results and manually pick locations.
- **Responsive Sidebar**: A multi-view sidebar that toggles between search/entry forms and a detailed results list.

## Technical Stack
- **Frontend**: React (Vite), Mapbox GL JS, `@mapbox/search-js-react`.
- **Backend**: Node.js, Express.
- **Database**: PostgreSQL with **PostGIS** extension for geospatial queries.
- **Styling**: Modern dark-themed UI with custom CSS.

## Data Model (PostgreSQL)

### Users Table
| Column | Type | Description |
| :--- | :--- | :--- |
| id | SERIAL | Primary Key |
| name | VARCHAR | User's full name |
| email | VARCHAR | Unique email |
| username | VARCHAR | Unique username |
| password_hash| TEXT | Bcrypt hashed password |

### Rides Table
| Column | Type | Description |
| :--- | :--- | :--- |
| id | SERIAL | Primary Key |
| host_user_id | INTEGER | FK to Users |
| source_location| GEOGRAPHY(POINT)| Pickup point (PostGIS) |
| destination_location| GEOGRAPHY(POINT)| Drop-off point (PostGIS) |
| price | NUMERIC | Total/Split price |
| seats_available| INTEGER | Available capacity |
| date_time | TIMESTAMP | Departure time |

## API Endpoints

### Rides
- `POST /api/rides`: Create a new ride listing.
- `GET /api/rides/search`: Query parameters: `sLat, sLng, sRad, dLat, dLng, dRad`. Returns rides matching both source and destination proximity.

### Auth
- `POST /api/users/register`: User signup with password hashing.

## Future Enhancements
- **Clerk Integration**: Replace custom auth with Clerk for robust session management.
- **Join Logic**: Backend endpoint to decrement `seats_available` and link passengers to rides.
- **Chat**: Real-time communication between host and passengers.
- **Payment Integration**: Digital split-payment processing.
